##' FFTCONV Package
##'
##' Testing out the FFTCONV
##'
##' @docType package
##' @author Andrew Lee \email{alee9619@uni.sydney.edu.au}
##' @name package1
##' @useDynLib ShiftConvolvePoibin

NULL

